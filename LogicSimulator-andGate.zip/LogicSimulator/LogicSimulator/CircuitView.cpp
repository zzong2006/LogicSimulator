// CircuitView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "LogicSimulator.h"
#include "CircuitView.h"
#include "LogicSimulatorDoc.h"

// CCircuitView

#define START 0
#define VTOH 1
#define HTOV 2
#define LINE 100
#define GATE 101


int object = LINE;
bool toggle = true;
CPoint line[3];
int state = 0;
IMPLEMENT_DYNCREATE(CCircuitView, CView)

CCircuitView::CCircuitView()
{

}

CCircuitView::~CCircuitView()
{

}

BEGIN_MESSAGE_MAP(CCircuitView, CView)
	ON_WM_LBUTTONDOWN()
	ON_WM_SETCURSOR()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()


// CCircuitView �׸����Դϴ�.

void CCircuitView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: ���⿡ �׸��� �ڵ带 �߰��մϴ�.
	CRect rect;
	GetClientRect(&rect);

	//for (int i = 0; i < rect.right; i+= UNIT)
	//{
		//for (int j = 0; j < rect.bottom; j+= UNIT)
		//{
			//pDC->SetPixel(i,j, RGB(128, 128, 128));
		//}
	//}
	pDC->Polyline(line, 3);
}


// CCircuitView �����Դϴ�.

#ifdef _DEBUG
void CCircuitView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CCircuitView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
#endif //_DEBUG


// CCircuitView �޽��� ó�����Դϴ�.


void CCircuitView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CLogicSimulatorDoc *pDoc = (CLogicSimulatorDoc *)GetDocument();

	CClientDC dc(this);
	Graphics graphics(dc);
	Pen P(Color(0, 0, 0),2);
	Point temp[4];

	int dec_x, dec_y;
	dec_x = point.x - point.x % UNIT;
	dec_y = point.y - point.y % UNIT;
	//and east
	
	if (object == GATE)
	{
		//if (pDoc->isSelected && pDoc->selectedType == _T("AND Gate")) {

		andPts[0] = Point(dec_x - 2 * UNIT, dec_y - 2 * UNIT);
		andPts[1] = Point(dec_x - 5 * UNIT, dec_y - 2 * UNIT);
		andPts[2] = Point(dec_x - 5 * UNIT, dec_y + 3 * UNIT);
		andPts[3] = Point(dec_x - 2 * UNIT, dec_y + 3 * UNIT);
		for (int i = 0; i < andPts.GetSize(); i++)
			temp[i] = andPts[i];
		graphics.DrawArc(&P, dec_x - 5 * UNIT, dec_y - 2 * UNIT, 5 * UNIT, 5 * UNIT, -80, 173);
		graphics.DrawLines(&P, temp, 4);

		prev_x = prev_y = INT_MAX;

		//for (int i = 0; i < andPts.GetSize(); i++)
			//andPts[i] = Point(0, 0);
		//}
		pDoc->isSelected = false;
	}
	else		//Line
	{
		if (toggle)
		{
			line[0] = CPoint(dec_x, dec_y);
			line[1] = line[0];
			line[2] = line[2];
			state = 0;
			toggle = false;
		}
		else
		{
			toggle = true;
		}
	}
	
	CView::OnLButtonDown(nFlags, point);
}


BOOL CCircuitView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CLogicSimulatorDoc *pDoc = (CLogicSimulatorDoc *) GetDocument();
	
	if (nHitTest==HTCLIENT)
	{
		CPoint point;
		::GetCursorPos(&point);
		ScreenToClient(&point);
		CRgn rgn;
		if (pDoc->isSelected)
			::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR1));
		else
			::SetCursor(AfxGetApp()->LoadStandardCursor(IDC_ARROW));
		return TRUE;
	}

	return CView::OnSetCursor(pWnd, nHitTest, message);
}


void CCircuitView::OnMouseMove(UINT nFlags, CPoint point)
{
	CLogicSimulatorDoc *pDoc = (CLogicSimulatorDoc *)GetDocument();

	CClientDC dc(this);
	Graphics graphics(dc);

	Point temp[4];
	Pen P(Color(190,190,190), 2);
	Pen DP(Color(255, 255, 255), 2);
	
	
	dec_x = point.x - point.x % UNIT;
	dec_y = point.y - point.y % UNIT;

	if (object == GATE)
	{
		if (prev_x == INT_MAX)
		{
			prev_x = dec_x;
			prev_y = dec_y;
		}
		//and east

		// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
		if (pDoc->isSelected && pDoc->selectedType == _T("AND Gate")) {

			for (int i = 0; i < andPts.GetSize(); i++)
				temp[i] = andPts[i];


			graphics.DrawArc(&DP, prev_x - 5 * UNIT, prev_y - 2 * UNIT, 5 * UNIT, 5 * UNIT, -80, 173);

			graphics.DrawLines(&DP, temp, 4);

			andPts[0] = Point(dec_x - 2 * UNIT, dec_y - 2 * UNIT);
			andPts[1] = Point(dec_x - 5 * UNIT, dec_y - 2 * UNIT);
			andPts[2] = Point(dec_x - 5 * UNIT, dec_y + 3 * UNIT);
			andPts[3] = Point(dec_x - 2 * UNIT, dec_y + 3 * UNIT);
			graphics.DrawArc(&P, dec_x - 5 * UNIT, dec_y - 2 * UNIT, 5 * UNIT, 5 * UNIT, -80, 173);

			graphics.DrawLines(&P, temp, 4);
			prev_x = dec_x;
			prev_y = dec_y;
		}
	}
	else
	{
		if (nFlags == MK_LBUTTON)
		{
			if (state == HTOV)
			{
				line[1].y = line[0].y;
				line[1].x = dec_x;
				line[2].x = line[1].x;
				line[2].y = dec_y;
				if (dec_x == line[0].x)
					state = VTOH;
				Invalidate();
			}
			else if (state == VTOH)
			{
				line[1].x = line[0].x;
				line[1].y = dec_y;
				line[2].y = line[1].y;
				line[2].x = dec_x;

				if (dec_y == line[0].y)
					state = HTOV;
				Invalidate();
			}
			else{
				if (dec_y != line[0].y)
					state = VTOH;
				else if (dec_x != line[0].x)
					state = HTOV;
			}
		}
		else
		{

		}
	}

	CView::OnMouseMove(nFlags, point);
}


void CCircuitView::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	CLogicSimulatorDoc *pDoc = (CLogicSimulatorDoc *)GetDocument();
	pDoc->isSelected = false;
	andPts.SetSize(4);
	prev_x = INT_MAX;
	prev_y = INT_MAX;
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
}
