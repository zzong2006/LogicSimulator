//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// LogicSimulator.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_LogicSimulatorTYPE          130
#define IDD_PROPERTYVIEW                310
#define IDC_STATIC_PROPGRID             310
#define IDB_BITMAP2                     317
#define IDC_CURSOR1                     318
#define IDB_BITMAP1                     319
#define IDB_FLIPFLOP                    323
#define IDB_GATE_SHADOW                 326
#define IDB_GATE                        327
#define IDB_GATE_ORI                    327
#define IDB_FLIPFLOP_SHADOW             328
#define IDB_WIRING                      329
#define IDB_BITMAP5                     330
#define IDB_WIRING_SHADOW               330
#define IDB_SEVEN_SEGMENT               332
#define IDC_MFCPROPERTYGRID1            1002
#define ID_CLICK_MODE                   32772
#define ID_32773                        32773
#define ID_BUTTON32774                  32774
#define ID_32775                        32775
#define ID_SELECT_MODE                  32776
#define ID_ON_SIMULATE                  32781
#define ID_32782                        32782
#define edi                             32783
#define ID_32788                        32788
#define ID_OUTPUT_GRAPH                 32789

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        333
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           313
#endif
#endif
